package Vehicles.il.ac.tau.cs.sw1.hw7;

public interface LandVehicle extends Vehicle {
	
	/**
	 * 
	 * @return the num of wheels
	 */
	public int getNumOfWheels();
	
	public void drive();

}
