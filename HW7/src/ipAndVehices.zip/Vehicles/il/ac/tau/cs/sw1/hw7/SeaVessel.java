package Vehicles.il.ac.tau.cs.sw1.hw7;

public interface SeaVessel extends Vehicle {
	
	public void launch();

}
