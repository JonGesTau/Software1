package Vehicles.il.ac.tau.cs.sw1.hw7;

public interface VehicleInSpace {
    // Updates the position of the shape
    public void move(int x, int y);
}
